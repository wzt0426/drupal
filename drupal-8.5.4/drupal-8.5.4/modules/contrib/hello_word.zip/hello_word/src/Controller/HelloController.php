<?php

namespace Drupal\hello_world\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Ajax\AjaxResponse;
use Symfony\Component\HttpFoundation\Request;
use Drupal;
use \Drupal\node\Entity\Node;
use \Drupal\file\Entity\File;


class HelloController extends ControllerBase {

  /**
   * Display the markup.
   *
   * @return array
   */
  public function content() {
    echo "aaa";
    return [
      '#type' => 'markup',
      '#markup' => $this->t('Hello, World!'),
    ];
  }


  public function create_content() {
    $response = new AjaxResponse();
    $request = \Drupal::request();
    $paramater = $request->request->all();
    $length = $paramater['length'];
    $target_id = [];
    for ($i = 0; $i < $length; $i++) {
      $name = 'upfiles_' . $i;
      $fileData = $_FILES[$name];

      $data = file_get_contents($fileData['tmp_name']);
      $file = file_save_data($data, "public://file/" . time(). $fileData['name'], FILE_EXISTS_REPLACE);


      array_push($target_id, [
        'target_id' => $file->id(),
        'alt' => 'Sample',
        'title' => 'Sample File'
      ]);
    }

    $data = array(
      'type' => 'article', 
      'title' => $paramater['title'], 
      'body' => $paramater['body'],
      'field_description' => $paramater['description'],
      'field_attch_file' => $target_id
    );
    
    $node = Drupal::entityManager()
      ->getStorage('node')
      ->create($data);
    $node->save();
    return $response;
  }
}